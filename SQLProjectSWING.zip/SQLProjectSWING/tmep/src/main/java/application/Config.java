package application;

public class Config {

    public final int menuHeight = 36;
    public final int buttonWidth = 120;
    public final int buttonHeight = 30;
    public final int margin = 4;
}
