package model;

public class Database {
}
